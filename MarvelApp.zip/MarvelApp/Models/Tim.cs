﻿namespace MarvelApp.Models
{
    public class Tim
    {
        public int Id { get; set; }
        public string? Naziv { get; set; }
        public string? Planet { get; set; }
    }
}
