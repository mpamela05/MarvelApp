﻿namespace MarvelApp.Models
{
    public class Heroj
    {
        public int Id { get; set; }
        public string Heroj_ime { get; set; }
        public string Lokacija { get; set; }
        public string Moc { get; set; }
        public string Osobnost { get; set; } 
    }
}
